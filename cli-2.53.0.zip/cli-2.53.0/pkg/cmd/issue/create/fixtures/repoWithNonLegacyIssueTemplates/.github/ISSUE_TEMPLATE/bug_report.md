---
name: Bug report
about: Report a bug or unexpected behavior
title: Bug Report
labels: bug

---

I wanna report a bug
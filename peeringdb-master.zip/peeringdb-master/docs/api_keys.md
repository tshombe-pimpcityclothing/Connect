This document has been moved to the [PeeringDB HOWTO's section](https://docs.peeringdb.com/howtos/).

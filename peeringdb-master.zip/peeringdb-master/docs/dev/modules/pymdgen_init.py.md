# peeringdb_server.pymdgen_init

pymdgen helper (doc generation)

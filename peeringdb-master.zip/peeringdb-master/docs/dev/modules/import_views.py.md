Generated from import_views.py on 2023-04-12 10:09:44.563425

# peeringdb_server.import_views

Define IX-F import preview, review and post-mortem views.

# Functions
---

## enable_basic_auth
`def enable_basic_auth(fn)`

A simple decorator to enable basic auth for a specific view.

---

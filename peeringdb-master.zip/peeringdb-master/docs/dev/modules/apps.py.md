Generated from apps.py on 2023-04-12 10:09:44.563425

# peeringdb_server.apps

Django apps configuration.

# Classes
---

## PeeringDBServerAppConfig

```
PeeringDBServerAppConfig(django.apps.config.AppConfig)
```

Class representing a Django application and its configuration.


### Methods

#### ready
`def ready(self)`

Override this method in subclasses to run code when Django starts.

---

Generated from settings.py on 2023-04-12 10:09:44.563425

# peeringdb_server.settings

(Being DEPRECATED) django settings preparation.

This is mostly DEPRECATED at this point and any new settings should be directly
defined in mainsite/settings.

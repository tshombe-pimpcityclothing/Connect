Generated from exceptions.py on 2023-04-12 10:09:44.563425

# peeringdb_server.exceptions

# Functions
---

## format_wait_time
`def format_wait_time(wait_time)`

Format wait time in seconds to human readable format

---

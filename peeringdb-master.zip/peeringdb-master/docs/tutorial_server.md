# Tutorial Server

When peeringdb runs in tutorial server mode

- entities are always automatically approved
- user to organization affiliation requests are automatically approved

Switch it on in your facsimile config

```yaml
misc:
  tutorial_mdoe: true
```

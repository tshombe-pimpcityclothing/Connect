This docuent has been moved to the [HOWTOs section](https://docs.peeringdb.com/howtos/) on our documentation site.

## Internet Exchange Network Information

Identified by the `ixlan` tag.

### Parent relationship:

- `ix` internet exchange

### Relationship(s):

- `ixpfx` prefixes
- `netixlan` network to exchange connections (through ixlan)

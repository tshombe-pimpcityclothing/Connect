## Network / Facility presence

Identified by the `netfac` tag.

### Parent relationship:

- `net` network

### Relationship(s):

- `fac` facility

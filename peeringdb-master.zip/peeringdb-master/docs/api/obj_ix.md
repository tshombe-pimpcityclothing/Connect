## Internet Exchange

Identified by the `ix` tag.

### Parent relationship:

- `org` organization

### Relationship(s):

- `ixlan` internet exchange network information
- `ixfac` exchange / facility presence

## Deleting objects

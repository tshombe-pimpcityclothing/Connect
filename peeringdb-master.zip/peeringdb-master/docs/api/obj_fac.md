## Facility (Datacenter)

Identified by the `fac` tag.

### Parent relationship:

- `org` organization

### Relationship(s):

- `ixfac` exchange / facility presence
- `netfac` network / facility presence

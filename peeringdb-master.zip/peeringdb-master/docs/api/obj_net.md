## Network

Identified by the `net` tag.

### Parent relationship:

- `org` organization

### Relationship(s):

- `netixlan` network to exchange connections (through `ixlan`)
- `netfac` network / facility presence
- `poc` points of contact

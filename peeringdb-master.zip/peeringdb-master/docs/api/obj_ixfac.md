## Internet Exchange / Facility presence

Identified by the `ixfac` tag.

### Parent relationship:

- `ix` internet exchange

### Relationship(s):

- `fac` facility

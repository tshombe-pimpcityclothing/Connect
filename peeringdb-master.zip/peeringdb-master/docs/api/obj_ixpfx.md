## Internet Exchange Prefix

Identified by the `ixpfx` tag.

### Parent relationship:

- `ix` internet exchange

### Relationship(s):

- None

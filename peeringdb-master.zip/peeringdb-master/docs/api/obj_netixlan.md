## Network to Internet Exchange connection

Identified by the `netixlan` tag.

### Parent relationship:

- `net` network

### Relationship(s):

- `ixlan` internet exchange network information

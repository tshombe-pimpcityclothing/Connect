## Organization

Identified by the `org` tag.

The organization is at the top of the peeringdb object hierarchy.

### Parent relationship:

- None

### Children relationship(s):

- `net` networks
- `fac` facilities
- `ix` exchanges

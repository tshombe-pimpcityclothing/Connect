"""
django-peeringdb backend setup (needed for pdb_load_data command)
"""

from django_peeringdb.client_adaptor.setup import configure  # noqa

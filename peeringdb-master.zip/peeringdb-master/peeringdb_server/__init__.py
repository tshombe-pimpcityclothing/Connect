default_app_config = "peeringdb_server.apps.PeeringDBServerAppConfig"

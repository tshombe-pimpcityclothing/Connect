## 1.3.0
- Multi cursor translation
- Multi line translation

## 1.2.0
- Replace selected text with translation

## 1.1.0
- Multi language support

## 1.0.4
- Initial release

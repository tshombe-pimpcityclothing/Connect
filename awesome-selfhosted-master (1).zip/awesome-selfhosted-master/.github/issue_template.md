Please do not open issues in this repository. Use https://github.com/awesome-selfhosted/awesome-selfhosted-data instead.

# Google Forms Add-ons

## [Notification Add-on](https://developers.google.com/apps-script/quickstart/forms-add-on)

This add-on allows Form creators to automatically
send email notifications when a form is submitted. In addition, the
add-on allows form creators to be notified when they have received
responses.

![Form Notifications](https://developers.google.com/apps-script/images/quickstart-form-notifications.png)

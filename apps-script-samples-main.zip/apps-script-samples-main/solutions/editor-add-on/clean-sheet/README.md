# Clean up data in a spreadsheet

See [developers.google.com](https://developers.google.com/apps-script/add-ons/clean-sheet) for additional details.


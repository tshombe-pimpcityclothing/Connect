# Create a tournament bracket

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/bracket-maker) for additional details.

# Manage new employee equipment requests

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/equipment-requests) for additional details.

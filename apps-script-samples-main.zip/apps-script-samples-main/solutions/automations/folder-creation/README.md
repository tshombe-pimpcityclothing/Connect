# Folder creation

This code sample is part of a video tutorial on how to combine AppSheet and Apps Script.

You can watch the video tutorial to find out how to use the sample.

<p align="center">
<iframe width="560" height="315" src="https://www.youtube.com/embed/Utl57R7I2Cs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</p>

See the [Google Apps Script Documentation](https://developers.google.com/apps-script/advanced/drive) for additional information about the advanced Google Drive services.

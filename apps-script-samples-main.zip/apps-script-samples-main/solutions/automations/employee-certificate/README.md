# Send personalized appreciation certificates to employees

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/employee-certificate) for additional details.

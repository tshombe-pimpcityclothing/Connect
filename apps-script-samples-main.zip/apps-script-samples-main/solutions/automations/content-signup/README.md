# Send curated content

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/content-signup) for additional details.

# Import CSV data to a spreadsheet

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/import-csv-sheets) for additional details.

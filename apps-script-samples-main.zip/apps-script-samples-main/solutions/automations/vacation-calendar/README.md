# Populate a team vacation calendar

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/vacation-calendar) for additional details.
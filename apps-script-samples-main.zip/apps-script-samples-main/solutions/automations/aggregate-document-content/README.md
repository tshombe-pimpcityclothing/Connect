# Aggregate content from multiple documents

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/aggregate-document-content) for additional details.

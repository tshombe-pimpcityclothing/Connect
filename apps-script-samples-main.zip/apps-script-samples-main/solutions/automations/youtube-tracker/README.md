# Track YouTube video views and comments

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/youtube-tracker) for additional details.
# Collect and review timesheets from employees

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/timesheets) for additional details.

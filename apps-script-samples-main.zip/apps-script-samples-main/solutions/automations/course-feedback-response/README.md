# Respond to feedback

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/course-feedback-response) for additional details.

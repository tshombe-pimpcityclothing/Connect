# Create a sign-up for an offsite

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/offsite-activity-signup) for additional details.

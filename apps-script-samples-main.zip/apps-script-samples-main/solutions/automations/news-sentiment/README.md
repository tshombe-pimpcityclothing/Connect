# Connect to an external API: Analyze news headlines

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/news-sentiment) for additional details.
# Upload files to Google Drive from Google Forms

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/upload-files) for additional details.

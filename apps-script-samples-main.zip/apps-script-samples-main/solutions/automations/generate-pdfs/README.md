# Generate and send PDFs from Google Sheets

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/generate-pdfs) for additional details.

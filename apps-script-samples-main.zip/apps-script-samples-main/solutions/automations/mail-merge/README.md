# Create a mail merge with Gmail & Google Sheets

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/mail-merge) for additional details.

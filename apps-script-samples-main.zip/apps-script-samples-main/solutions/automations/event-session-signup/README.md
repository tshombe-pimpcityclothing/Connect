# Create a sign-up for sessions at a conference

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/event-session-signup) for additional details.

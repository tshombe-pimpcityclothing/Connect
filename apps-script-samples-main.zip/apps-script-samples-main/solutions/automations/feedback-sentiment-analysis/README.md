# Analyze sentiment of open-ended feedback

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/feedback-sentiment-analysis) for additional details.
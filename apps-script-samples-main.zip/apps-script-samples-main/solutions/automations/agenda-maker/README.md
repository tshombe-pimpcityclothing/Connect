# Make an agenda for meetings

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/agenda-maker) for additional details.

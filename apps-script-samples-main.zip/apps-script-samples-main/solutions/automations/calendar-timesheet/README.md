# Record time and activities in Calendar and Sheets

See [developers.google.com](https://developers.google.com/apps-script/samples/automations/calendar-timesheet) for additional details.

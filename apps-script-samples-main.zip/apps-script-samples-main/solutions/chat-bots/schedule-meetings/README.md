# Schedule meetings from Google Chat

See [developers.google.com](https://developers.google.com/apps-script/samples/chat-apps/schedule-meetings) for additional details.


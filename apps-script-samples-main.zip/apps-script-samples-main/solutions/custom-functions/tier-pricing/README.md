# Calculate a tiered pricing discount

See [developers.google.com](https://developers.google.com/apps-script/samples/custom-functions/tier-pricing) for additional details.


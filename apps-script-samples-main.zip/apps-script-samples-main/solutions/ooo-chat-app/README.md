# OOO Chat App

Sample code for a custom Google Chat app that manages your out of office tasks.

Learn more about [Chat apps](https://developers.google.com/chat).

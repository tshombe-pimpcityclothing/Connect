# Copy macros to other spreadsheets

See [developers.google.com](https://developers.google.com/apps-script/add-ons/share-macro) for additional details.


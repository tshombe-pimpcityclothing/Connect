# Preview links from Google Books with smart chips

See 
https://developers.google.com/workspace/add-ons/samples/preview-links-google-books
for additional details.
